package src.resources;

public class CMDArgs {
	public static String ALGORITHM;
	public static int SPAWN_RATE;
	public static String MAP_FILE;
}
